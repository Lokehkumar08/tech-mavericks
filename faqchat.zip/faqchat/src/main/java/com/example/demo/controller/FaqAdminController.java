package com.example.demo.controller;

import com.example.demo.model.Faq;
import com.example.demo.service.FaqService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/faqs/admin")
public class FaqAdminController {

    @Autowired
    private FaqService faqService;

    @GetMapping
    public ResponseEntity<?> getAllFaqs() {
        return new ResponseEntity<>(faqService.getAllFaqs(), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Faq> addFaq(@RequestBody Faq faq) {
        faqService.saveFaq(faq);
        return new ResponseEntity<>(faq, HttpStatus.CREATED);
    }
}
