package com.example.demo.controller;

import com.example.demo.model.Faq;
import com.example.demo.service.FaqService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/faqs/chat")
public class FaqChatController {

    @Autowired
    private FaqService faqService;

    @GetMapping("/suggestions")
    public ResponseEntity<?> getFaqSuggestions() {
        return new ResponseEntity<>(faqService.getAllFaqs(), HttpStatus.OK);
    }

    @PostMapping("/search")
    public ResponseEntity<?> searchFaq(@RequestBody SearchRequest request) {
        Faq faq = faqService.searchFaq(request.getQuery());
        if (faq != null) {
            return new ResponseEntity<>(faq, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("No FAQ found for query: " + request.getQuery(), HttpStatus.NOT_FOUND);
        }
    }
    
    public static class SearchRequest {
        private String query;
        public String getQuery() { return query; }
        public void setQuery(String query) { this.query = query; }
    }
}
