package com.example.demo.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.sql.Timestamp;

@Entity
@Table(name = "brandings")
public class Branding {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false, length = 255)
    private String title;
    
    @Column(nullable = false, columnDefinition = "TEXT")
    private String description;
    
    @Lob
    @Column(name = "image_data", nullable = false)
    private byte[] imageData;
    
    @Column(name = "redirect_url", nullable = false, length = 500)
    private String redirectUrl;
    
    // Field for expiry date and time
    @Column(name = "expiry_datetime", nullable = false)
    private LocalDateTime expiryDateTime;
    
    @Column(name = "is_active")
    private Boolean isActive = true;
    
    @Column(name = "created_at", columnDefinition = "DATETIME DEFAULT CURRENT_TIMESTAMP")
    private LocalDateTime createdAt;
    
    @Column(name = "created_by", nullable = false)
    private Long createdBy;
    
    @Column(name = "updated_by")
    private Long updatedBy;
    
    @Column(name = "last_updated", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    private Timestamp lastUpdated;
    
    // Getters and setters

    public Long getId() { 
        return id; 
    }
    public void setId(Long id) { 
        this.id = id; 
    }
    
    public String getTitle() { 
        return title; 
    }
    public void setTitle(String title) { 
        this.title = title; 
    }
    
    public String getDescription() { 
        return description; 
    }
    public void setDescription(String description) { 
        this.description = description; 
    }
    
    public byte[] getImageData() { 
        return imageData; 
    }
    public void setImageData(byte[] imageData) { 
        this.imageData = imageData; 
    }
    
    public String getRedirectUrl() { 
        return redirectUrl; 
    }
    public void setRedirectUrl(String redirectUrl) { 
        this.redirectUrl = redirectUrl; 
    }
    
    public LocalDateTime getExpiryDateTime() { 
        return expiryDateTime; 
    }
    public void setExpiryDateTime(LocalDateTime expiryDateTime) { 
        this.expiryDateTime = expiryDateTime; 
    }
    
    public Boolean getIsActive() { 
        return isActive; 
    }
    public void setIsActive(Boolean isActive) { 
        this.isActive = isActive; 
    }
    
    public LocalDateTime getCreatedAt() { 
        return createdAt; 
    }
    public void setCreatedAt(LocalDateTime createdAt) { 
        this.createdAt = createdAt; 
    }
    
    public Long getCreatedBy() { 
        return createdBy; 
    }
    public void setCreatedBy(Long createdBy) { 
        this.createdBy = createdBy; 
    }
    
    public Long getUpdatedBy() { 
        return updatedBy; 
    }
    public void setUpdatedBy(Long updatedBy) { 
        this.updatedBy = updatedBy; 
    }
    
    public Timestamp getLastUpdated() { 
        return lastUpdated; 
    }
    public void setLastUpdated(Timestamp lastUpdated) { 
        this.lastUpdated = lastUpdated; 
    }
}
