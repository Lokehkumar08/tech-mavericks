package com.example.demo.service;

import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ElasticSearchService {
    
    // Stub method for fetching query suggestions from Elasticsearch
    public List<String> getSuggestionsFromElastic() {
        // TODO: Implement actual Elasticsearch integration
        return List.of("Sample question 1", "Sample question 2", "Sample question 3");
    }
}
