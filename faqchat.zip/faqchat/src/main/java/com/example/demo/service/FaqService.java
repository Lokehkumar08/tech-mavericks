package com.example.demo.service;

import com.example.demo.model.Faq;
import com.example.demo.repository.FaqRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class FaqService {

    @Autowired
    private FaqRepository faqRepository;

    public List<Faq> getAllFaqs() {
        return faqRepository.findAll();
    }

    public Faq searchFaq(String query) {
        List<Faq> faqs = faqRepository.findByQuestionContainingIgnoreCaseAndIsActiveTrue(query);
        return (faqs != null && !faqs.isEmpty()) ? faqs.get(0) : null;
    }
    
    public List<String> getCategories() {
        return faqRepository.findDistinctCategories();
    }
    
    public List<Faq> getFaqsByCategory(String category) {
        return faqRepository.findByCategoryAndIsActiveTrue(category);
    }
    
    public void saveFaq(Faq faq) {
        faqRepository.save(faq);
    }
}
