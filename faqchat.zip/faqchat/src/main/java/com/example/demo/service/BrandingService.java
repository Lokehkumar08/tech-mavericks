package com.example.demo.service;

import com.example.demo.model.Branding;
import com.example.demo.repository.BrandingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class BrandingService {

    @Autowired
    private BrandingRepository brandingRepository;

    public Optional<Branding> getBrandingById(Long id) {
        return brandingRepository.findById(id);
    }

    public Branding saveBranding(Branding branding) {
        return brandingRepository.save(branding);
    }

    public List<Branding> getActiveBrandings() {
        return brandingRepository.findByIsActiveTrueAndExpiryDateTimeAfter(LocalDateTime.now());
    }
}
