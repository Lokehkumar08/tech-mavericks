package com.example.demo.repository;

import com.example.demo.model.Faq;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface FaqRepository extends JpaRepository<Faq, Long> {
    List<Faq> findByQuestionContainingIgnoreCaseAndIsActiveTrue(String query);
    
    @Query("SELECT DISTINCT f.category FROM Faq f WHERE f.isActive = true")
    List<String> findDistinctCategories();
    
    List<Faq> findByCategoryAndIsActiveTrue(String category);
}
