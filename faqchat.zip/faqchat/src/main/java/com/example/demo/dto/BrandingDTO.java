package com.example.demo.dto;

import java.time.LocalDateTime;

public class BrandingDTO {
    private Long id;
    private String title;
    private String description;
    private String imageBase64;
    private String redirectUrl;
    private LocalDateTime expiryDateTime;
    private Boolean isActive;
    private LocalDateTime createdAt;
    private Long createdBy;
    private Long updatedBy;

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getImageBase64() { return imageBase64; }
    public void setImageBase64(String imageBase64) { this.imageBase64 = imageBase64; }
    
    public String getRedirectUrl() { return redirectUrl; }
    public void setRedirectUrl(String redirectUrl) { this.redirectUrl = redirectUrl; }
    
    public LocalDateTime getExpiryDateTime() { return expiryDateTime; }
    public void setExpiryDateTime(LocalDateTime expiryDateTime) { this.expiryDateTime = expiryDateTime; }
    
    public Boolean getIsActive() { return isActive; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public Long getCreatedBy() { return createdBy; }
    public void setCreatedBy(Long createdBy) { this.createdBy = createdBy; }
    
    public Long getUpdatedBy() { return updatedBy; }
    public void setUpdatedBy(Long updatedBy) { this.updatedBy = updatedBy; }
}
