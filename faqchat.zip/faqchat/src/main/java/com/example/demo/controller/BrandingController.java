package com.example.demo.controller;

import com.example.demo.dto.BrandingDTO;
import com.example.demo.model.Branding;
import com.example.demo.service.BrandingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/brandings")
@CrossOrigin(origins = "http://localhost:3000")
public class BrandingController {

    @Autowired
    private BrandingService brandingService;

    // GET active brandings with image data converted to Base64
    @GetMapping
    public ResponseEntity<List<BrandingDTO>> getActiveBrandings() {
        List<Branding> brandings = brandingService.getActiveBrandings();
        List<BrandingDTO> dtos = brandings.stream().map(b -> {
            BrandingDTO dto = new BrandingDTO();
            dto.setId(b.getId());
            dto.setTitle(b.getTitle());
            dto.setDescription(b.getDescription());
            if (b.getImageData() != null) {
                dto.setImageBase64(Base64.getEncoder().encodeToString(b.getImageData()));
            }
            dto.setRedirectUrl(b.getRedirectUrl());
            dto.setExpiryDateTime(b.getExpiryDateTime());
            dto.setIsActive(b.getIsActive());
            dto.setCreatedAt(b.getCreatedAt());
            dto.setCreatedBy(b.getCreatedBy());
            dto.setUpdatedBy(b.getUpdatedBy());
            return dto;
        }).collect(Collectors.toList());
        return new ResponseEntity<>(dtos, HttpStatus.OK);
    }

    // POST endpoint to add new branding (unchanged)
    @PostMapping
    public ResponseEntity<Branding> addBranding(
            @RequestParam("title") String title,
            @RequestParam("description") String description,
            @RequestParam("redirectUrl") String redirectUrl,
            @RequestParam("expiryDateTime") String expiryDateTimeStr,
            @RequestParam("imageFile") MultipartFile imageFile,
            @RequestParam("created_by") Long createdBy) {
        Branding branding = new Branding();
        branding.setTitle(title);
        branding.setDescription(description);
        branding.setRedirectUrl(redirectUrl);
        branding.setExpiryDateTime(LocalDateTime.parse(expiryDateTimeStr));
        branding.setCreatedBy(createdBy);
        try {
            branding.setImageData(imageFile.getBytes());
        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        Branding saved = brandingService.saveBranding(branding);
        return new ResponseEntity<>(saved, HttpStatus.CREATED);
    }
    
    // NEW: PUT endpoint to update existing branding with optional image update
    @PutMapping("/{id}")
    public ResponseEntity<?> updateBranding(
            @PathVariable Long id,
            @RequestParam("title") String title,
            @RequestParam("description") String description,
            @RequestParam("redirectUrl") String redirectUrl,
            @RequestParam("expiryDateTime") String expiryDateTimeStr,
            @RequestParam(value = "imageFile", required = false) MultipartFile imageFile) {
        Optional<Branding> existingOpt = brandingService.getBrandingById(id);
        if (existingOpt.isPresent()) {
            Branding existing = existingOpt.get();
            existing.setTitle(title);
            existing.setDescription(description);
            existing.setRedirectUrl(redirectUrl);
            existing.setExpiryDateTime(LocalDateTime.parse(expiryDateTimeStr));
            if (imageFile != null && !imageFile.isEmpty()) {
                try {
                    existing.setImageData(imageFile.getBytes());
                } catch (IOException e) {
                    return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
                }
            }
            brandingService.saveBranding(existing);
            return ResponseEntity.ok("Branding updated successfully");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Branding not found");
        }
    }
}
